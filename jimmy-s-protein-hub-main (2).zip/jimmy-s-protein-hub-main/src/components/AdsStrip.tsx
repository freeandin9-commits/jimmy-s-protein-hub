import { useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

type Ad = {
  id: string;
  title: string;
  image_url: string;
  link_url: string | null;
  focal_x?: number | null;
  focal_y?: number | null;
  zoom?: number | null;
};

export function AdsStrip() {
  const scrollerRef = useRef<HTMLDivElement>(null);
  const { data: ads = [] } = useQuery({
    queryKey: ["ads", "public"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ads")
        .select("id, title, image_url, link_url, focal_x, focal_y, zoom")
        .eq("active", true)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return data as Ad[];
    },
  });

  if (ads.length === 0) return null;

  const scroll = (dir: "left" | "right") => {
    const el = scrollerRef.current;
    if (!el) return;
    const delta = el.clientWidth * 0.8 * (dir === "left" ? -1 : 1);
    el.scrollBy({ left: delta, behavior: "smooth" });
  };

  return (
    <section className="bg-background">
      <div className="container relative mx-auto px-4 pt-4">
        <div
          ref={scrollerRef}
          className="flex snap-x snap-mandatory gap-3 overflow-x-auto scroll-smooth pb-2 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        >
          {ads.map((ad) => {
            const fx = ad.focal_x ?? 50;
            const fy = ad.focal_y ?? 50;
            const z = ad.zoom ?? 1;
            const card = (
              <div className="relative aspect-[16/9] h-full w-full overflow-hidden rounded-xl border border-border bg-card">
                <img
                  src={ad.image_url}
                  alt={ad.title || "Ad"}
                  className="h-full w-full object-cover"
                  style={{
                    objectPosition: `${fx}% ${fy}%`,
                    transform: z !== 1 ? `scale(${z})` : undefined,
                  }}
                  loading="lazy"
                />
              </div>
            );
            return (
              <div
                key={ad.id}
                className="w-[80%] shrink-0 snap-start sm:w-[55%] md:w-[42%] lg:w-[32%]"
              >
                {ad.link_url ? (
                  <a
                    href={ad.link_url}
                    target={ad.link_url.startsWith("http") ? "_blank" : undefined}
                    rel="noopener noreferrer"
                    className="block"
                  >
                    {card}
                  </a>
                ) : (
                  card
                )}
              </div>
            );
          })}
        </div>

        {ads.length > 1 && (
          <>
            <button
              type="button"
              onClick={() => scroll("left")}
              aria-label="Scroll ads left"
              className="absolute left-6 top-1/2 hidden h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-background/90 text-foreground shadow-md backdrop-blur transition-opacity hover:bg-background md:flex"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => scroll("right")}
              aria-label="Scroll ads right"
              className="absolute right-6 top-1/2 hidden h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-background/90 text-foreground shadow-md backdrop-blur transition-opacity hover:bg-background md:flex"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </>
        )}
      </div>
    </section>
  );
}
